Chai Dastaan — AI Image & Content Workflow
Made by Maria Parveen — Project 02, The Sky Gen

CONTENTS:
- tsg-ai-p02-mariaparveen_01.jpg to _12.jpg = 12 final AI images
- Chai_Dastaan_Slideshow_ENGLISH.gif = GIF Slideshow
- tsg-ai-p02-mariaparveen_Chai_Dastaan_ENGLISH.pdf = Complete Report (Brand Brief, Prompt Log, Iteration, Human Editing, 10 Copies, Video Storyboard, Workflow, Limitations)
- Chai_Dastaan_Website.html = Website (open in browser)

DISCLOSURE: All images are AI-generated and human-edited. Fictional brand.
VIDEO: Use GIF + CapCut storyboard in PDF Section 07 to make 30-sec MP4.
SUBMISSION: Upload this whole folder to ONE Google Drive folder, Anyone with link can view, submit form with name Maria Parveen before 12 Oct 2026, 11:59 PM PKT.
